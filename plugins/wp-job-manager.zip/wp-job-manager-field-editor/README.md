wp-job-manager-field-editor
===========================

Ajax field editor for WP Job Manager and WP Job Manager Resumes

Most bugs have been worked out, should be pretty much fully functional, here's some screenshots until i finish the readme:

## Edit Fields
<img src="https://smyl.es/wurdp/assets/jmfe-edit-o.gif">

## Disable Fields
<img src="https://smyl.es/wurdp/assets/jmfe-disable-o.gif">

## Add New Fields
<img src="https://smyl.es/wurdp/assets/jmfe-add_new-o.gif">
