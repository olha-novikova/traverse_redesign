<?php

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Class WP_Job_Manager_Field_Editor_Themes_Jobify
 *
 * @since 1.7.0
 *
 */
class WP_Job_Manager_Field_Editor_Themes_Jobify {

	/**
	 * WP_Job_Manager_Field_Editor_Themes_Jobify constructor.
	 */
	function __construct() {

		add_filter( 'field_editor_output_options', array( $this, 'auto_output' ), 10, 2 );
		add_filter( 'job_manager_field_editor_set_featured_image', array( $this, 'featured_image' ), 10 );
		add_filter( 'field_editor_auto_output_li_actions', array( $this, 'add_li_actions' ) );

	}

	/**
	 * Add Hooks that should be wrapped in <li> tags
	 *
	 *
	 * @since 1.7.0
	 *
	 * @param $actions
	 *
	 * @return array
	 */
	function add_li_actions( $actions ){

		$actions[] = 'job_listing_company_social_before';
		$actions[] = 'job_listing_company_social_after';

		return $actions;
	}

	/**
	 * Jobify Theme custom action output areas
	 *
	 * Requires Jobify 2.0.1.2 or newer
	 *
	 * @since @@since
	 *
	 * @param $current_options
	 * @param $type
	 *
	 * @return array|bool
	 */
	function auto_output( $current_options, $type ) {

		if ( $type === 'company' ) {
			$type = "job";
		}
		if ( $type === 'resume_fields' ) {
			$type = "resume";
		}

		$field_groups = ! empty( $type ) ? array( $type ) : array( 'job', 'resume' );

		$theme_version = WP_Job_Manager_Field_Editor_Integration::check_theme( 'jobify', '2.0.1.2', 'version' );
		if ( ! $theme_version ) {
			return FALSE;
		}

		$jobify_options_job = array(
			'2.0.1.2' => array(
				'single_job_listing_info_jobify'      => array(
					'label'                          => '---' . __( 'Jobify Single Listing Page', 'wp-job-manager-field-editor' ),
					'single_job_listing_info_before' => __( 'Single Job Listing Before', 'wp-job-manager-field-editor' ),
					'single_job_listing_info_after'  => __( 'Single Job Listing After', 'wp-job-manager-field-editor' ),
					'single_job_listing_info_start'  => __( 'Single Job Listing Start', 'wp-job-manager-field-editor' ),
					'single_job_listing_info_end'    => __( 'Single Job Listing End', 'wp-job-manager-field-editor' ),
				),
			),
			'2.0.2.2' => array(
				'single_job_listing_jobify_widgets'    => array(
					'label'                             => '---' . __( 'Jobify Theme Widgets', 'wp-job-manager-field-editor' ),
					'jobify_widget_job_apply_after'     => __( 'After Apply', 'wp-job-manager-field-editor' ),
					'job_listing_company_social_before' => __( 'Before Company Social Icons', 'wp-job-manager-field-editor' ),
					'job_listing_company_social_after'  => __( 'After Company Social Icons', 'wp-job-manager-field-editor' ),
				),
			)
		);

		$jobify_options_resume = array(
			'2.0.1.2' => array(
				'single_resume_info_jobify' => array(
					'label'                     => '---' . __( 'Jobify Single Listing Page', 'wp-job-manager-field-editor' ),
					'single_resume_info_before' => __( 'Single Resume Listing Before', 'wp-job-manager-field-editor' ),
					'single_resume_info_after'  => __( 'Single Resume Listing After', 'wp-job-manager-field-editor' ),
					'single_resume_info_start'  => __( 'Single Resume Listing Start', 'wp-job-manager-field-editor' ),
					'single_resume_info_end'    => __( 'Single Resume Listing End', 'wp-job-manager-field-editor' ),
				),
			)
		);

		$build_options = array();

		foreach ( $field_groups as $group ) {

			if ( ! isset( ${"jobify_options_$group"} ) ) {
				continue;
			}

			foreach ( ${"jobify_options_$group"} as $version => $options ) {

				if ( version_compare( $theme_version, $version, 'ge' ) ) {
					$build_options = array_merge_recursive( $build_options, $options );
				}

			}
		}

		// Loop through all built options (separated by groups) and rebuild non multi-dimensional array
		foreach ( $build_options as $option_group => $option_options ) {
			$current_options[ $option_group ] = $option_options['label'];
			unset( $option_options ['label'] );
			$current_options += $option_options;
		}

		return $current_options;

	}

	/**
	 * Prevent set/save featured_image meta key as featured image
	 *
	 * Jobify uses the `featured_image` meta key on its own, outside of the actual featured image, and
	 * the featured image should be set by the core WPJM from the `company_logo` field.
	 *
	 * @since 1.5.0
	 *
	 * @param $allow
	 *
	 * @return bool
	 */
	function featured_image( $allow ){
		return false;
	}
}