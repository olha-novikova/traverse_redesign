=== Apply with Facebook ===
Contributors: mikejolley, kraftbj, panoskountanis
Requires at least: 3.8
Tested up to: 4.7
Stable tag: 1.0.3
License: GNU General Public License v3.0

Add an "Apply with Facebook" button to job listings which have an 'email' apply method. Requires an App from Facebook (https://developers.facebook.com/quickstarts/?platform=web).

= Documentation =

Usage instructions for this plugin can be found on the documentation site: [https://wpjobmanager.com/documentation/add-ons/apply-with-facebook](https://wpjobmanager.com/documentation/add-ons/apply-with-facebook).

== Installation ==

To install this plugin, please refer to the guide here: [http://codex.wordpress.org/Managing_Plugins#Manual_Plugin_Installation](http://codex.wordpress.org/Managing_Plugins#Manual_Plugin_Installation)

== Changelog ==

= 1.0.3 =
* Update API to 2.8.

= 1.0.2 =
* Update API to 2.4.

= 1.0.1 =
* Fix checkbox.

= 1.0.0 =
* First release.
