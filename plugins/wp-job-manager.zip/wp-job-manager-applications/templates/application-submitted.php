<p class="job-manager-message">
	<?php _e( 'Your job application has been submitted successfully', 'wp-job-manager-applications' ); ?>
</p>