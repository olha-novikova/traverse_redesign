<div class="job-manager-applications-applied-notice">
	<?php  _e( 'You have already applied for this job.', 'wp-job-manager-applications' ); ?>
</div>