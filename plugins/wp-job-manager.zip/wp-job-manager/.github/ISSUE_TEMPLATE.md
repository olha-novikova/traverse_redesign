<!-- 
Thanks for contributing to WP Job Manager! Enter a clear title (e.g. "Search error when using plus sign") and proceed. 
-->

#### What I Expected To Happen

#### What Happened Instead

#### Steps to Reproduce the Bug

<!--
PLEASE NOTE:
- These comments won't show up when you submit the issue.
- Try to add as much detail as possible. Be specific!
- GitHub issues aren't for support! If you have questions, use this form: https://wpjobmanager.com/support/
- If you're requesting a new feature, explain why you'd like it to be added.
-->
