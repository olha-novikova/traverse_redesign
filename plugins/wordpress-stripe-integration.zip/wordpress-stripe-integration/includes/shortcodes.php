<?php
if (!session_id())
    session_start();
function base_stripe_payment_form() {?>
    <div style="text-align: center;">
    <div style="display: inline-block; text-align: left">
        <?php
        if(isset($_GET['payment']) && $_GET['payment'] == 'paid') {
            echo '<p class="success">' . __('Thank you for your payment.', 'stripe_domain') . '</p>';
        } else { ?>
            <div class="payment-errors">
                <?php
                if(isset($_GET['payment']) && $_GET['payment'] == 'failed'){
                    if ( isset ($_SESSION['error']))
                        echo $_SESSION['error'];
                    unset ($_SESSION['error']);
                }
                ?>
            </div>

            <form class="credit-card" method="POST" id="stripe-payment-form">
                <div class="form-header">
                    <h4 class="title">Client Info</h4>
                </div>
                <div class="form-body">
                    <div>
                        <input placeholder="Client/Company" type="text" name="company">
                    </div>
                    <div>
                        <input placeholder="$ Amount to Pay" type="text" name="amount">
                    </div>
                    <h4 class="title">Credit Card Details</h4>
                    <div>
                        <input placeholder="Name" class="card-name" type="text">
                    </div>
                    <input type="text" placeholder="Card Number" autocomplete="off" class="card-number">
                    <div class="date-field">
                        <div class="month" style="display: inline-block;">
                            <select class="card-expiry-month">
                                <option value="1">January</option>
                                <option value="2">February</option>
                                <option value="3">March</option>
                                <option value="4">April</option>
                                <option value="5">May</option>
                                <option value="6">June</option>
                                <option value="7">July</option>
                                <option value="8">August</option>
                                <option value="9">September</option>
                                <option value="10">October</option>
                                <option value="11">November</option>
                                <option value="12">December</option>
                            </select>
                        </div>
                        <div class="year" style="display: inline-block;">
                            <select class="card-expiry-year">
                            <?php
                            for ( $year = date("Y"); $year < date("Y")+10; $year++ )
                            {
                                echo('<option value="'.$year.'">'.$year.'</option>');
                            }
                            ?>
                            </select>
                        </div>
                    </div>
                    <div class="card-verification">
                        <div class="cvv-input">
                            <input type="text" size="4" placeholder="CVV" autocomplete="off" class="card-cvc">
                        </div>
                    </div>
                    <input type="hidden" name="action" value="stripe"/>
                    <input type="hidden" name="redirect" value="<?php echo get_permalink(); ?>"/>
                    <input type="hidden" name="stripe_nonce" value="<?php echo wp_create_nonce('stripe-nonce'); ?>"/>
                    <button type="submit" id="stripe-submit"><?php _e('Submit Payment', 'stripe_domain'); ?></button>
                </div>
            </form>
            <?php
        }?>
    </div>
    </div>
<?php
}
add_shortcode('payment_form', 'base_stripe_payment_form');