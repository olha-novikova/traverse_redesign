(function($){

	FLBuilder.registerModuleHelper('icon', {
		
		rules: {
			icon: {
				required: true
			},
			size: {
				number: true,
				required: true
			}
		}
	});

})(jQuery);